# Football Career Sim : version 1.0 (base jouable)

## Lancer en local
    npm install
    npx expo start

## Générer l'APK Android (cloud Expo, gratuit pour un usage personnel)
    npm install -g eas-cli
    eas login
    eas build -p android --profile preview

L'APK se télécharge depuis le lien affiché à la fin du build.
Pour le Play Store, utiliser le profil production (AAB).

## Pousser sur GitHub
    git init && git add . && git commit -m "v1.0"
    git remote add origin <votre-repo>
    git push -u origin main

## Prochaines étapes (1.1)
- Remplacer src/data/seed.js par une base complète : vérifier chaque club, joueur, note et entraîneur.
- Ajouter le calendrier de championnat, les médias et les relations avec l'entraîneur.
- Ajouter l'équipe nationale.
