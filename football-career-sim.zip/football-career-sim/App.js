import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';
import { GameProvider, useGame } from './src/store/GameContext';
import { colors } from './src/theme';
import CreateScreen from './src/screens/CreateScreen';
import HomeScreen from './src/screens/HomeScreen';
import TrainingScreen from './src/screens/TrainingScreen';
import MatchScreen from './src/screens/MatchScreen';
import TransferScreen from './src/screens/TransferScreen';
import PlayerScreen from './src/screens/PlayerScreen';

const Tab = createBottomTabNavigator();

function Root() {
  const { career, loading } = useGame();
  if (loading) return null;
  if (!career) return <CreateScreen />;
  return (
    <Tab.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.bg },
        headerTintColor: colors.text,
        tabBarStyle: { backgroundColor: colors.card, borderTopColor: colors.border },
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.muted,
      }}
    >
      <Tab.Screen name="Accueil" component={HomeScreen} />
      <Tab.Screen name="Entraînement" component={TrainingScreen} />
      <Tab.Screen name="Match" component={MatchScreen} />
      <Tab.Screen name="Mercato" component={TransferScreen} />
      <Tab.Screen name="Mon joueur" component={PlayerScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <GameProvider>
      <NavigationContainer>
        <StatusBar style="light" />
        <Root />
      </NavigationContainer>
    </GameProvider>
  );
}
