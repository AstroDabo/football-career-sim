export const colors = {
  bg: '#0b1020',
  card: '#151c2f',
  border: '#24304a',
  text: '#f8fafc',
  muted: '#94a3b8',
  accent: '#22c55e',
  danger: '#ef4444',
};
