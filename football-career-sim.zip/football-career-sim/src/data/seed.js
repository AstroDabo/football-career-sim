// Base de données initiale. Les notes sont INDICATIVES et doivent être vérifiées
// et complétées (voir README). Les clubs et joueurs listés sont à enrichir.
export const CLUBS = [
  { id: 'psg', name: 'Paris Saint-Germain', country: 'France', league: 'Ligue 1', rating: 84 },
  { id: 'ol', name: 'Olympique Lyonnais', country: 'France', league: 'Ligue 1', rating: 72 },
  { id: 'rma', name: 'Real Madrid', country: 'Espagne', league: 'La Liga', rating: 86 },
  { id: 'mci', name: 'Manchester City', country: 'Angleterre', league: 'Premier League', rating: 85 },
  { id: 'fcb', name: 'FC Bayern Munich', country: 'Allemagne', league: 'Bundesliga', rating: 84 },
  { id: 'rcs', name: 'Racing Club de Strasbourg', country: 'France', league: 'Ligue 1', rating: 62 },
];

export const PLAYERS = [
  { id: 'p1', firstName: 'Kylian', lastName: 'Mbappé', clubId: 'rma', position: 'FW', rating: 91 },
  { id: 'p2', firstName: 'Vinícius', lastName: 'Júnior', clubId: 'rma', position: 'FW', rating: 88 },
  { id: 'p3', firstName: 'Erling', lastName: 'Haaland', clubId: 'mci', position: 'FW', rating: 90 },
  { id: 'p4', firstName: 'Kevin', lastName: 'De Bruyne', clubId: 'mci', position: 'MF', rating: 87 },
  { id: 'p5', firstName: 'Harry', lastName: 'Kane', clubId: 'fcb', position: 'FW', rating: 89 },
  { id: 'p6', firstName: 'Achraf', lastName: 'Hakimi', clubId: 'psg', position: 'DF', rating: 85 },
  { id: 'p7', firstName: 'Ousmane', lastName: 'Dembélé', clubId: 'psg', position: 'FW', rating: 85 },
];

export const POSITIONS = [
  { code: 'GK', label: 'Gardien' },
  { code: 'DF', label: 'Défenseur' },
  { code: 'MF', label: 'Milieu' },
  { code: 'FW', label: 'Attaquant' },
];
