import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { CLUBS } from '../data/seed';

const KEY = 'football_career_save_v1';
const GameContext = createContext(null);

export function GameProvider({ children }) {
  const [career, setCareer] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    AsyncStorage.getItem(KEY).then(raw => {
      if (raw) setCareer(JSON.parse(raw));
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    if (!loading) {
      if (career) AsyncStorage.setItem(KEY, JSON.stringify(career));
      else AsyncStorage.removeItem(KEY);
    }
  }, [career, loading]);

  const createCareer = useCallback(form => {
    const club = CLUBS.find(c => c.id === form.clubId);
    setCareer({
      clubId: club.id,
      clubName: club.name,
      clubRating: club.rating,
      season: 2026,
      matchday: 0,
      log: [`Carrière commencée à ${club.name}`],
      player: {
        firstName: form.firstName,
        lastName: form.lastName,
        age: form.age,
        position: form.position,
        number: Math.floor(Math.random() * 98) + 1,
        rating: 55,
        fatigue: 10,
        morale: 70,
        injuryDays: 0,
        goals: 0,
        matches: 0,
        salary: 5000,
      },
    });
  }, []);

  const update = useCallback(next => setCareer(next), []);
  const resetCareer = useCallback(() => setCareer(null), []);

  return (
    <GameContext.Provider value={{ career, loading, createCareer, update, resetCareer }}>
      {children}
    </GameContext.Provider>
  );
}

export const useGame = () => useContext(GameContext);
