import React from 'react';
import { ScrollView, Text, TouchableOpacity, View, StyleSheet, Alert } from 'react-native';
import { useGame } from '../store/GameContext';
import { colors } from '../theme';

export default function HomeScreen() {
  const { career, resetCareer } = useGame();
  const p = career.player;

  const confirmReset = () =>
    Alert.alert('Nouvelle carrière', 'La carrière actuelle sera supprimée. Continuer ?', [
      { text: 'Annuler', style: 'cancel' },
      { text: 'Supprimer', style: 'destructive', onPress: resetCareer },
    ]);

  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 16 }}>
      <View style={s.hero}>
        <Text style={s.number}>#{p.number}</Text>
        <Text style={s.name}>{p.firstName} {p.lastName}</Text>
        <Text style={s.muted}>{career.clubName} · Saison {career.season}</Text>
        <Text style={s.overall}>{Math.round(p.rating)}</Text>
        <Text style={s.muted}>Note générale sur 100</Text>
      </View>
      <View style={s.stats}>
        <Stat label="Matchs" value={p.matches} />
        <Stat label="Buts" value={p.goals} />
        <Stat label="Forme" value={`${Math.round(100 - p.fatigue)}%`} />
        <Stat label="Moral" value={`${Math.round(p.morale)}%`} />
      </View>
      <Text style={s.section}>Journal</Text>
      {career.log.slice(0, 10).map((l, i) => (
        <Text key={i} style={s.log}>• {l}</Text>
      ))}
      <TouchableOpacity style={s.danger} onPress={confirmReset}>
        <Text style={{ color: colors.danger, fontWeight: '700' }}>Recommencer une carrière</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function Stat({ label, value }) {
  return (
    <View style={s.stat}>
      <Text style={s.statValue}>{value}</Text>
      <Text style={s.muted}>{label}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  hero: { backgroundColor: colors.card, borderRadius: 16, padding: 20, alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  number: { color: colors.accent, fontWeight: '800' },
  name: { color: colors.text, fontSize: 24, fontWeight: '800', marginTop: 4 },
  overall: { color: colors.text, fontSize: 56, fontWeight: '900', marginTop: 12 },
  muted: { color: colors.muted },
  stats: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 16 },
  stat: { flex: 1, backgroundColor: colors.card, margin: 4, padding: 12, borderRadius: 12, alignItems: 'center' },
  statValue: { color: colors.text, fontSize: 18, fontWeight: '700' },
  section: { color: colors.text, fontWeight: '700', fontSize: 16, marginTop: 24, marginBottom: 8 },
  log: { color: colors.muted, marginBottom: 6 },
  danger: { marginTop: 32, padding: 14, alignItems: 'center', borderRadius: 12, borderWidth: 1, borderColor: colors.danger },
});
