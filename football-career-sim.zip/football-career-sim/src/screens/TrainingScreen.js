import React, { useState } from 'react';
import { ScrollView, Text, TouchableOpacity, StyleSheet, View } from 'react-native';
import { useGame } from '../store/GameContext';
import { TRAININGS, train, rest } from '../engine/simulation';
import { colors } from '../theme';

export default function TrainingScreen() {
  const { career, update } = useGame();
  const [msg, setMsg] = useState('');

  const run = fn => {
    const res = fn(career);
    update(res.career);
    setMsg(res.msg);
  };

  const p = career.player;
  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 16 }}>
      <Text style={s.title}>Entraînement</Text>
      <Text style={s.muted}>Fatigue : {Math.round(p.fatigue)}% · Blessure : {p.injuryDays > 0 ? `${p.injuryDays} j` : 'aucune'}</Text>
      {TRAININGS.map(t => (
        <TouchableOpacity key={t.id} style={s.card} onPress={() => run(c => train(c, t.id))}>
          <Text style={s.cardTitle}>{t.label}</Text>
          <Text style={s.muted}>Progression de la note, fatigue +12</Text>
        </TouchableOpacity>
      ))}
      <TouchableOpacity style={[s.card, { borderColor: colors.accent }]} onPress={() => run(rest)}>
        <Text style={s.cardTitle}>Repos</Text>
        <Text style={s.muted}>Récupération de fatigue</Text>
      </TouchableOpacity>
      {!!msg && <View style={s.msg}><Text style={{ color: colors.text }}>{msg}</Text></View>}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  title: { color: colors.text, fontSize: 24, fontWeight: '800', marginBottom: 8 },
  muted: { color: colors.muted, marginBottom: 12 },
  card: { backgroundColor: colors.card, padding: 16, borderRadius: 12, marginBottom: 10, borderWidth: 1, borderColor: colors.border },
  cardTitle: { color: colors.text, fontWeight: '700', fontSize: 16 },
  msg: { backgroundColor: colors.card, padding: 14, borderRadius: 12, marginTop: 8 },
});
