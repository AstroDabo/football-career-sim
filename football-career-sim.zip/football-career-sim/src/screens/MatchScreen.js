import React, { useState } from 'react';
import { ScrollView, Text, TouchableOpacity, StyleSheet, View } from 'react-native';
import { useGame } from '../store/GameContext';
import { playMatch } from '../engine/simulation';
import { CLUBS } from '../data/seed';
import { colors } from '../theme';

export default function MatchScreen() {
  const { career, update } = useGame();
  const [result, setResult] = useState(null);

  const play = () => {
    const opponents = CLUBS.filter(c => c.id !== career.clubId);
    const opp = opponents[Math.floor(Math.random() * opponents.length)];
    const res = playMatch(career, opp);
    update(res.career);
    setResult({ ...res, opponent: opp });
  };

  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 16 }}>
      <Text style={s.title}>Match</Text>
      <Text style={s.muted}>Journée {career.matchday + 1} · {career.clubName}</Text>
      <TouchableOpacity style={s.button} onPress={play}>
        <Text style={s.buttonText}>Jouer le match</Text>
      </TouchableOpacity>
      {result && (
        <View style={s.card}>
          <Text style={s.score}>
            {result.score ? `${career.clubName} ${result.score.own} - ${result.score.opp} ${result.opponent.name}` : 'Match manqué'}
          </Text>
          {result.events.length === 0 && <Text style={s.muted}>Aucun événement marquant.</Text>}
          {result.events.map((e, i) => (
            <Text key={i} style={s.event}>{e.minute}' {e.text}</Text>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  title: { color: colors.text, fontSize: 24, fontWeight: '800' },
  muted: { color: colors.muted, marginVertical: 8 },
  button: { backgroundColor: colors.accent, padding: 16, borderRadius: 12, alignItems: 'center', marginVertical: 12 },
  buttonText: { color: '#052e16', fontWeight: '800' },
  card: { backgroundColor: colors.card, padding: 16, borderRadius: 12 },
  score: { color: colors.text, fontSize: 18, fontWeight: '800', marginBottom: 10 },
  event: { color: colors.text, marginBottom: 6 },
});
