import React from 'react';
import { ScrollView, Text, View, StyleSheet } from 'react-native';
import { useGame } from '../store/GameContext';
import { colors } from '../theme';

export default function PlayerScreen() {
  const { career } = useGame();
  const p = career.player;
  const rows = [
    ['Nom', `${p.firstName} ${p.lastName}`],
    ['Âge', p.age],
    ['Poste', p.position],
    ['Numéro de maillot', `#${p.number}`],
    ['Club', career.clubName],
    ['Note générale', `${Math.round(p.rating)} / 100`],
    ['Matchs joués', p.matches],
    ['Buts', p.goals],
    ['Salaire', `${p.salary.toLocaleString('fr-FR')} € / mois`],
  ];
  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 16 }}>
      <Text style={s.title}>Mon joueur</Text>
      {rows.map(([k, v]) => (
        <View key={k} style={s.row}>
          <Text style={s.muted}>{k}</Text>
          <Text style={s.value}>{v}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  title: { color: colors.text, fontSize: 24, fontWeight: '800', marginBottom: 12 },
  row: { flexDirection: 'row', justifyContent: 'space-between', backgroundColor: colors.card, padding: 14, borderRadius: 10, marginBottom: 8 },
  muted: { color: colors.muted },
  value: { color: colors.text, fontWeight: '700' },
});
