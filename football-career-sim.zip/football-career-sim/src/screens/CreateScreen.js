import React, { useState } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View, StyleSheet } from 'react-native';
import { useGame } from '../store/GameContext';
import { CLUBS, POSITIONS } from '../data/seed';
import { colors } from '../theme';

export default function CreateScreen() {
  const { createCareer } = useGame();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [age, setAge] = useState('17');
  const [position, setPosition] = useState('MF');
  const [clubId, setClubId] = useState(CLUBS[0].id);

  const valid = firstName.trim() && lastName.trim() && Number(age) >= 15 && Number(age) <= 40;

  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 20, paddingTop: 60 }}>
      <Text style={s.title}>Nouvelle carrière</Text>
      <Text style={s.label}>Prénom</Text>
      <TextInput style={s.input} value={firstName} onChangeText={setFirstName} />
      <Text style={s.label}>Nom</Text>
      <TextInput style={s.input} value={lastName} onChangeText={setLastName} />
      <Text style={s.label}>Âge</Text>
      <TextInput style={s.input} value={age} onChangeText={setAge} keyboardType="number-pad" />
      <Text style={s.label}>Poste</Text>
      <View style={s.row}>
        {POSITIONS.map(p => (
          <Chip key={p.code} label={p.label} active={position === p.code} onPress={() => setPosition(p.code)} />
        ))}
      </View>
      <Text style={s.label}>Club de départ</Text>
      {CLUBS.map(c => (
        <TouchableOpacity key={c.id} style={[s.club, clubId === c.id && s.clubActive]} onPress={() => setClubId(c.id)}>
          <Text style={s.clubName}>{c.name}</Text>
          <Text style={s.muted}>{c.league} · {c.rating}</Text>
        </TouchableOpacity>
      ))}
      <TouchableOpacity
        style={[s.button, !valid && { opacity: 0.4 }]}
        disabled={!valid}
        onPress={() => createCareer({ firstName: firstName.trim(), lastName: lastName.trim(), age: Number(age), position, clubId })}
      >
        <Text style={s.buttonText}>Commencer la carrière</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function Chip({ label, active, onPress }) {
  return (
    <TouchableOpacity style={[s.chip, active && s.chipActive]} onPress={onPress}>
      <Text style={{ color: colors.text }}>{label}</Text>
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  title: { color: colors.text, fontSize: 28, fontWeight: '800', marginBottom: 20 },
  label: { color: colors.muted, marginTop: 14, marginBottom: 6 },
  input: { backgroundColor: colors.card, color: colors.text, padding: 12, borderRadius: 10, borderWidth: 1, borderColor: colors.border },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 20, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border },
  chipActive: { borderColor: colors.accent, backgroundColor: '#14532d' },
  club: { backgroundColor: colors.card, padding: 14, borderRadius: 10, marginBottom: 8, borderWidth: 1, borderColor: colors.border },
  clubActive: { borderColor: colors.accent },
  clubName: { color: colors.text, fontWeight: '600' },
  muted: { color: colors.muted },
  button: { backgroundColor: colors.accent, padding: 16, borderRadius: 12, marginTop: 24, alignItems: 'center' },
  buttonText: { color: '#052e16', fontWeight: '800', fontSize: 16 },
});
