import React, { useState } from 'react';
import { ScrollView, Text, TouchableOpacity, StyleSheet, View } from 'react-native';
import { useGame } from '../store/GameContext';
import { transferOffers } from '../engine/simulation';
import { CLUBS } from '../data/seed';
import { colors } from '../theme';

export default function TransferScreen() {
  const { career, update } = useGame();
  const [offers, setOffers] = useState([]);
  const [msg, setMsg] = useState('');

  const askAgent = () => {
    const found = transferOffers(career, CLUBS);
    setOffers(found);
    setMsg(found.length ? '' : 'Votre agent ne reçoit aucune offre pour le moment.');
  };

  const accept = offer => {
    update({
      ...career,
      clubId: offer.clubId,
      clubName: offer.clubName,
      clubRating: CLUBS.find(c => c.id === offer.clubId).rating,
      player: { ...career.player, salary: offer.salary },
      log: [`Transfert vers ${offer.clubName}`, ...career.log].slice(0, 60),
    });
    setOffers([]);
    setMsg(`Vous avez signé avec ${offer.clubName}.`);
  };

  return (
    <ScrollView style={s.screen} contentContainerStyle={{ padding: 16 }}>
      <Text style={s.title}>Mercato</Text>
      <Text style={s.muted}>Salaire actuel : {career.player.salary.toLocaleString('fr-FR')} € / mois</Text>
      <TouchableOpacity style={s.button} onPress={askAgent}>
        <Text style={s.buttonText}>Demander à mon agent</Text>
      </TouchableOpacity>
      {offers.map(o => (
        <View key={o.clubId} style={s.card}>
          <Text style={s.cardTitle}>{o.clubName}</Text>
          <Text style={s.muted}>Salaire proposé : {o.salary.toLocaleString('fr-FR')} € / mois</Text>
          <TouchableOpacity style={s.accept} onPress={() => accept(o)}>
            <Text style={s.buttonText}>Accepter</Text>
          </TouchableOpacity>
        </View>
      ))}
      {!!msg && <Text style={s.muted}>{msg}</Text>}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  title: { color: colors.text, fontSize: 24, fontWeight: '800' },
  muted: { color: colors.muted, marginVertical: 8 },
  button: { backgroundColor: colors.accent, padding: 16, borderRadius: 12, alignItems: 'center', marginVertical: 12 },
  buttonText: { color: '#052e16', fontWeight: '800' },
  card: { backgroundColor: colors.card, padding: 16, borderRadius: 12, marginBottom: 10 },
  cardTitle: { color: colors.text, fontWeight: '700', fontSize: 16 },
  accept: { backgroundColor: colors.accent, padding: 12, borderRadius: 10, alignItems: 'center', marginTop: 10 },
});
