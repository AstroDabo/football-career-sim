const clamp = (v, a = 0, b = 100) => Math.max(a, Math.min(b, v));
const rnd = (a, b) => a + Math.random() * (b - a);

export const TRAININGS = [
  { id: 'technique', label: 'Technique', gain: 0.4 },
  { id: 'physique', label: 'Physique', gain: 0.3 },
  { id: 'tactique', label: 'Tactique', gain: 0.35 },
];

export function train(career, trainingId) {
  const t = TRAININGS.find(x => x.id === trainingId);
  const p = { ...career.player };
  if (p.injuryDays > 0) return { career, msg: 'Vous êtes blessé : entraînement impossible.' };
  if (p.fatigue >= 90) return { career, msg: 'Trop fatigué, repos conseillé.' };
  p.rating = clamp(p.rating + t.gain * rnd(0.5, 1.5), 0, 99);
  p.fatigue = clamp(p.fatigue + 12);
  p.morale = clamp(p.morale + 1);
  return {
    career: { ...career, player: p, log: [`Entraînement ${t.label}`, ...career.log].slice(0, 60) },
    msg: `Entraînement « ${t.label} » terminé.`,
  };
}

export function rest(career) {
  const p = {
    ...career.player,
    fatigue: clamp(career.player.fatigue - 30),
    injuryDays: Math.max(0, career.player.injuryDays - 1),
  };
  return { career: { ...career, player: p }, msg: 'Repos récupéré.' };
}

export function playMatch(career, opponent) {
  const p = { ...career.player };
  const events = [];
  if (p.injuryDays > 0) {
    p.injuryDays -= 1;
    return {
      career: { ...career, player: p, matchday: career.matchday + 1 },
      events: [{ minute: 0, text: 'Vous êtes blessé et manquez la rencontre.' }],
      score: null,
    };
  }

  const starter = Math.random() < clamp((p.rating - 40) / 40, 0.15, 0.95);
  const ownStrength = career.clubRating;
  let ownGoals = 0;
  let oppGoals = 0;

  for (let m = 1; m <= 90; m++) {
    if (Math.random() < (ownStrength / (ownStrength + opponent.rating)) * 0.02) {
      ownGoals++;
      if (starter && Math.random() < p.rating / 300) {
        p.goals++;
        events.push({ minute: m, text: `But de ${p.firstName} ${p.lastName} !` });
      } else {
        events.push({ minute: m, text: `But de ${career.clubName}.` });
      }
    }
    if (Math.random() < (opponent.rating / (ownStrength + opponent.rating)) * 0.02) {
      oppGoals++;
      events.push({ minute: m, text: `But de ${opponent.name}.` });
    }
    if (starter && Math.random() < 0.004 + p.fatigue / 20000) {
      p.injuryDays = Math.round(rnd(3, 20));
      events.push({ minute: m, text: `Blessure de ${p.firstName} ${p.lastName}, il doit sortir.` });
      break;
    }
  }

  const result = ownGoals > oppGoals ? 'win' : ownGoals < oppGoals ? 'loss' : 'draw';
  p.matches++;
  p.fatigue = clamp(p.fatigue + 25);
  p.rating = clamp(p.rating + (result === 'win' ? 0.5 : result === 'loss' ? -0.2 : 0.1), 0, 99);
  p.morale = clamp(p.morale + (result === 'win' ? 5 : result === 'loss' ? -5 : 0));
  events.sort((a, b) => a.minute - b.minute);

  return {
    career: {
      ...career,
      player: p,
      matchday: career.matchday + 1,
      log: [`${career.clubName} ${ownGoals}-${oppGoals} ${opponent.name}`, ...career.log].slice(0, 60),
    },
    events,
    score: { own: ownGoals, opp: oppGoals, result },
  };
}

export function transferOffers(career, clubs) {
  const others = clubs.filter(c => c.id !== career.clubId);
  if (career.player.rating < 60 || Math.random() < 0.6) return [];
  const pick = others[Math.floor(Math.random() * others.length)];
  return [{ clubId: pick.id, clubName: pick.name, salary: Math.round(career.player.salary * rnd(1.2, 1.8)) }];
}
